# Run Microsoft SQl Server and initialization script (at the same time)
/app/init-data.sh & /opt/mssql/bin/sqlservr
# /opt/mssql/bin/sqlservr
