<template>
  <div>
    <span class="red--text">404</span>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>