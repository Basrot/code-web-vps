import { ViewMode } from "./contants";

export const defaultPatientViewMode = ViewMode.Table;
