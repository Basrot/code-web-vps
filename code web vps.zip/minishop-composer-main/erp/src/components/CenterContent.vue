<template>
  <v-container fill-height class="pa-0 ma-0">
    <v-row class="pa-0 ma-0">
      <v-col cols="12" justify="center" align="center" class="pa-0 ma-0">
        <slot />
      </v-col>
    </v-row>
  </v-container>
</template>
