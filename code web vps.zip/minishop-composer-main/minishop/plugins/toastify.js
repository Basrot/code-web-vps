import Vue from 'vue';
import VueToastify from "vue-toastify";

Vue.use( VueToastify );