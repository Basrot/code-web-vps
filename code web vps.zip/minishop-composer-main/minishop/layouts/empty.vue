<template lang="html">
    <div class="page-wrapper">
        <nuxt></nuxt>
    </div>
</template>