<template>
	<main class="main">
		<page-header
			title="Testimonials"
			subtitle="Elements"
		></page-header>


		<div class="page-content">
			<div class="container">
				<h2 class="title text-center mb-3">
					Quote Sign
					<span class="title-separator">/</span> Centered Align
				</h2>

				<div class="swiper-carousel swiper-testimonials swiper-1">
					<div v-swiper:swiper1="carouselSetting1">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>

									<cite>
										Jenson Gregory
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>

							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus qui ut ipsum.Velit quos ipsa exercitationem, vel unde obcaecati impedit eveniet non. ”</p>

									<cite>
										Damon Stone
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>

							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Molestias animi illo natus ut quod neque ad accusamus praesentium fuga! Dolores odio alias sapiente odit delectus quasi, explicabo a, modi voluptatibus. Perferendis perspiciatis, voluptate, distinctio earum veritatis animi tempora eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>

									<cite>
										John Smith
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
						</div>
					</div>
					<div class="swiper-nav nav-rounded">
						<div class="swiper-prev">
							<i class="icon-angle-left"></i>
						</div>
						<div class="swiper-next">
							<i class="icon-angle-right"></i>
						</div>
					</div>
					<div class="swiper-dots"></div>
				</div>

				<hr class="mt-5 mb-5" />
				<h2 class="title text-center mb-3">
					Quote Sign
					<span class="title-separator">/</span> Centered Align
					<span class="title-separator">/</span> 2 Columns
				</h2>

				<div class="swiper-carousel swiper-testimonials swiper-2">
					<div v-swiper:swiper2="carouselSetting2">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi tortor eu nibh. Nullam mollis. ”</p>
									<cite>
										Jenson Gregory
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus. ”</p>

									<cite>
										Victoria Ventura
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Molestias animi illo natus ut quod neque ad accusamus praesentium fuga! Dolores odio alias sapiente odit delectus quasi, explicabo a, modi voluptatibus. Perferendis, voluptate, distinctio earum veritatis animi. ”</p>

									<cite>
										John Smith
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
						</div>
					</div>
					<div class="swiper-nav nav-rounded">
						<div class="swiper-prev">
							<i class="icon-angle-left"></i>
						</div>
						<div class="swiper-next">
							<i class="icon-angle-right"></i>
						</div>
					</div>
					<div class="swiper-dots"></div>
				</div>

				<hr class="mt-5 mb-5" />
				<h2 class="title text-center mb-3">
					Quote Sign
					<span class="title-separator">/</span> Centered Align
					<span class="title-separator">/</span> 3 Columns
				</h2>

				<div class="swiper-carousel swiper-testimonials swiper-3">
					<div v-swiper:swiper3="carouselSetting3">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus quet vel, dapibus id, mattis vel, nisi tortor eu nibh. Nullam mollis. ”</p>
									<cite>
										Jenson Gregory
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusand. ”</p>

									<cite>
										Victoria Ventura
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Molestias animi illo natus ut quod neque ad accusamus praesentium fuga! Dolores odio alias sapiente odit delectus quasi, explicab, modi animi. ”</p>

									<cite>
										Angelica Lynch
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial testimonial-icon text-center">
									<p>“ Molestias animi illo natus ut quod neque ad accusamus praesentium fuga! Dolores odio alias sapiente odit delectus quasi, explicab. ”</p>

									<cite>
										John Smith
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
						</div>
					</div>
					<div class="swiper-nav nav-rounded">
						<div class="swiper-prev">
							<i class="icon-angle-left"></i>
						</div>
						<div class="swiper-next">
							<i class="icon-angle-right"></i>
						</div>
					</div>
					<div class="swiper-dots"></div>
				</div>
			</div>

			<div class="mb-5"></div>

			<parallax
				bg-image="./images/backgrounds/bg-large.jpg"
				class="bg-image bg-overlay pt-5 pb-4"
			>
				<div class="container">
					<h2 class="title text-center text-white mb-3">
						Quote Sign
						<span class="title-separator">/</span> Centered Align
						<span class="title-separator">/</span> Dark Background
					</h2>

					<div class="swiper-carousel swiper-testimonials swiper-light swiper-4">
						<div v-swiper:swiper4="carouselSetting4">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<blockquote class="testimonial testimonial-icon text-center text-white">
										<p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>

										<cite>
											Jenson Gregory
											<span>Customer</span>
										</cite>
									</blockquote>
								</div>

								<div class="swiper-slide">
									<blockquote class="testimonial testimonial-icon text-center">
										<p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus qui ut ipsum.Velit quos ipsa exercitationem, vel unde obcaecati impedit eveniet non. ”</p>

										<cite>
											Damon Stone
											<span>Customer</span>
										</cite>
									</blockquote>
								</div>

								<div class="swiper-slide">
									<blockquote class="testimonial testimonial-icon text-center">
										<p>“ Molestias animi illo natus ut quod neque ad accusamus praesentium fuga! Dolores odio alias sapiente odit delectus quasi, explicabo a, modi voluptatibus. Perferendis perspiciatis, voluptate, distinctio earum veritatis animi tempora eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>

										<cite>
											John Smith
											<span>Customer</span>
										</cite>
									</blockquote>
								</div>
							</div>
						</div>
						<div class="swiper-nav nav-rounded">
							<div class="swiper-prev">
								<i class="icon-angle-left"></i>
							</div>
							<div class="swiper-next">
								<i class="icon-angle-right"></i>
							</div>
						</div>
						<div class="swiper-dots"></div>
					</div>
				</div>
			</parallax>

			<div class="mb-5"></div>

			<div class="container">
				<h2 class="title text-center mb-3">
					Customer Photo
					<span class="title-separator">/</span> Centered Align
				</h2>

				<div class="swiper-carousel swiper-testimonials-photo">
					<div class="swiper-carousel swiper-testimonials swiper-light swiper-5">
						<div v-swiper:swiper5="carouselSetting5">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<blockquote class="testimonial text-center">
										<img
											src="~/static/images/testimonials/user-1.jpg"
											alt="user"
										/>
										<p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>

										<cite>
											Jenson Gregory
											<span>Customer</span>
										</cite>
									</blockquote>
								</div>

								<div class="swiper-slide">
									<blockquote class="testimonial text-center">
										<img
											src="~/static/images/testimonials/user-2.jpg"
											alt="user"
										/>
										<p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus qui ut ipsum.Velit quos ipsa exercitationem, vel unde obcaecati impedit eveniet non. ”</p>

										<cite>
											Victoria Ventura
											<span>Customer</span>
										</cite>
									</blockquote>
								</div>
							</div>
						</div>
						<div class="swiper-nav nav-rounded">
							<div class="swiper-prev">
								<i class="icon-angle-left"></i>
							</div>
							<div class="swiper-next">
								<i class="icon-angle-right"></i>
							</div>
						</div>
						<div class="swiper-dots"></div>
					</div>
				</div>

				<hr class="mt-5 mb-5" />
				<h2 class="title text-center mb-3">
					Customer Photo
					<span class="title-separator">/</span> Centered Align
					<span class="title-separator">/</span> 2 Columns
				</h2>

				<div class="swiper-carousel swiper-testimonials-photo swiper-6">
					<div v-swiper:swiper6="carouselSetting6">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<blockquote class="testimonial text-center">
									<img
										src="~/static/images/testimonials/user-1.jpg"
										alt="user"
									/>
									<p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi tortor eu nibh. Nullam mollis. ”</p>
									<cite>
										Jenson Gregory
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial text-center">
									<img
										src="~/static/images/testimonials/user-2.jpg"
										alt="user"
									/>
									<p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus. ”</p>

									<cite>
										Victoria Ventura
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
							<div class="swiper-slide">
								<blockquote class="testimonial text-center">
									<img
										src="~/static/images/testimonials/user-1.jpg"
										alt="user"
									/>
									<p>“ Molestias animi illo natus ut quod neque ad accusamus praesentium fuga! Dolores odio alias sapiente odit delectus quasi, explicabo a, modi voluptatibus. Perferendis, voluptate, distinctio earum veritatis animi. ”</p>

									<cite>
										John Smith
										<span>Customer</span>
									</cite>
								</blockquote>
							</div>
						</div>
					</div>
					<div class="swiper-nav nav-rounded">
						<div class="swiper-prev">
							<i class="icon-angle-left"></i>
						</div>
						<div class="swiper-next">
							<i class="icon-angle-right"></i>
						</div>
					</div>
					<div class="swiper-dots"></div>
				</div>
			</div>
		</div>

		<element-list></element-list>
	</main>
</template>

<script>
import PageHeader from '~/components/elements/PageHeader';
import Parallax from '~/components/elements/Parallax';
import ElementList from '~/components/partial/elements/ElementList';
import { carouselSettingDefault } from '~/utilities/carousel';

export default {
	components: {
		PageHeader,
		ElementList,
		Parallax
	},
	data: function() {
		return {
			carouselSetting1: {
				...carouselSettingDefault,
				spaceBetween: 0,
				slidesPerView: 1,
				navigation: {
					nextEl: '.swiper-1 .swiper-next',
					prevEl: '.swiper-1 .swiper-prev'
				},
				pagination: {
					el: '.swiper-1 .swiper-dots',
					clickable: true
				}
			},
			carouselSetting2: {
				...carouselSettingDefault,
				slidesPerView: 2,
				navigation: {
					nextEl: '.swiper-2 .swiper-next',
					prevEl: '.swiper-2 .swiper-prev'
				},
				pagination: {
					el: '.swiper-2 .swiper-dots',
					clickable: true
				}
			},
			carouselSetting3: {
				...carouselSettingDefault,
				slidesPerView: 3,
				navigation: {
					nextEl: '.swiper-3 .swiper-next',
					prevEl: '.swiper-3 .swiper-prev'
				},
				pagination: {
					el: '.swiper-3 .swiper-dots',
					clickable: true
				}
			},
			carouselSetting4: {
				...carouselSettingDefault,
				spaceBetween: 0,
				slidesPerView: 1,
				navigation: {
					nextEl: '.swiper-4 .swiper-next',
					prevEl: '.swiper-4 .swiper-prev'
				},
				pagination: {
					el: '.swiper-4 .swiper-dots',
					clickable: true
				}
			},
			carouselSetting5: {
				...carouselSettingDefault,
				spaceBetween: 0,
				slidesPerView: 1,
				navigation: {
					nextEl: '.swiper-5 .swiper-next',
					prevEl: '.swiper-5 .swiper-prev'
				},
				pagination: {
					el: '.swiper-5 .swiper-dots',
					clickable: true
				}
			},
			carouselSetting6: {
				...carouselSettingDefault,
				slidesPerView: 2,
				navigation: {
					nextEl: '.swiper-6 .swiper-next',
					prevEl: '.swiper-6 .swiper-prev'
				},
				pagination: {
					el: '.swiper-6 .swiper-dots',
					clickable: true
				}
			}
		};
	}
};
</script>