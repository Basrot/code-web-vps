<template>
    <main class="main">
        <element-list class="mt-3"></element-list>
    </main>
</template>

<script>
import ElementList from '~/components/partial/elements/ElementList';

export default {
    components: {
        ElementList
    }
};
</script>